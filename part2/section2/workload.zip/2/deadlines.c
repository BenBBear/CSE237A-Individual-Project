// Generated deadlines for the test workload
// This file has to be included only in main_week4.c
long long workloadDeadlines[] = {
	200000,
	300000,
	600000,
	500000,
	500000,
	500000,
	500000,
	150000,
};
