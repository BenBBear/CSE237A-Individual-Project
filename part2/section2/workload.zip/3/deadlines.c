// Generated deadlines for the test workload
// This file has to be included only in main_week4.c
long long workloadDeadlines[] = {
	200000,
	600000,
	400000,
	200000,
	600000,
	200000,
	400000,
	150000,
};
